game "gta5"
fx_version "cerulean"

lua54 "yes"

author "Keriyem (discord.gg/gQeKYvDTQt)"
version "1.0.5"


shared_scripts {
    "resources.lua",
    "shared/clientloader.lua"
}

server_scripts {
    "server/server.lua"
}

escrow_ignore {
    "resources.lua"
}