Resources = {
    ["testscript"] = { -- Resource Name
        "config.lua",
        "client.lua",
    },
}